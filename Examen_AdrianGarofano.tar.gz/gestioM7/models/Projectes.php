<?php
include_once 'Model.php';

class Projectes extends Model{
    
   protected $taula="projectes";
 
  

    public function afegir($nom,$descripcio,$dataInici,$dataFi,$estat) {
 	$sql ="insert into projectes(nom,descripcio,dataInici,dataFi,estat) values 
			 (:nom,:descripcio,:dataInici,:dataFi,:estat)";
	$ordre = $this->bd->prepare($sql);	 
	$ordre->bindValue(':nom',$nom);
	$ordre->bindValue(':descripcio',$descripcio);
	$ordre->bindValue(':dataInici',$dataInici);
	$ordre->bindValue(':dataFi',$dataFi);
	$ordre->bindValue(':estat',$estat);
	$res = $ordre->execute(); 
        return $res;

    }


    public function actualitzar($codi,$nom,$descripcio,$dataInici,$dataFi,$estat) {
 	$sql ="update projectes set nom=:nom,descripcio=:descripcio, dataInici=:dataInici, dataFi=:dataFi, estat=:estat 
             where codi=:codi";
	$ordre = $this->bd->prepare($sql);	 
        $ordre->bindValue(':codi',$codi);
	$ordre->bindValue(':nom',$nom);
	$ordre->bindValue(':descripcio',$descripcio);
	$ordre->bindValue(':dataInici',$dataInici);
	$ordre->bindValue(':dataFi',$dataFi);
	$ordre->bindValue(':estat',$estat);
	
	$res = $ordre->execute(); 
        return $res;

    }

public function getMembres($codiprojecte){
	$sql="select * from usuaris where codi in(SELECT codiusuari from usuarisprojecte where codiprojecte=:codiprojecte)";
	$sentencia=$this->bd->prepare($sql);
	$sentencia->bindvalue(':codiprojecte',$codiprojecte);
	$sentencia->execute();
	$usuaris=$sentencia->fetchAll(PDO::FETCH_ASSOC);
	return $usuaris;

}

public function getNoMembres($codiprojecte){
	$sql="select * from usuaris where codi not in(SELECT codiusuari from usuarisprojecte where codiprojecte=:codiprojecte)";
	$sentencia=$this->bd->prepare($sql);
	$sentencia->bindvalue(':codiprojecte',$codiprojecte);
	$sentencia->execute();
	$usuaris=$sentencia->fetchAll(PDO::FETCH_ASSOC);
	return $usuaris;
}
	public function assignarusuaris($codiprojecte,$usuaris){
		$sql="insert into usuarisprojecte(codiprojecte,codiusuari) values(:codiprojecte,:codiusuari)";
		$orde=$this->bd->prepare($sql);
		$orde->bindvalue(':codiprojecte',$codiprojecte);
		foreach($usuaris as $codiusuari){
		$orde->bindvalue(':codiusuari',$codiusuari);
		$res=$orde->execute();
		}
	}	
	
	public function treureusuari($codiprojecte,$usuaris){
		$sql="delete from usuarisprojecte where codiprojecte=:codiprojecte AND codiusuari=:codiusuari";
		$orde=$this->bd->prepare($sql);
		$orde->bindvalue(':codiprojecte',$codiprojecte);		
		$orde->bindvalue(':codiusuari',$usuaris);
		$res=$orde->execute();
		
	}
	public function mostraprojectes($codiprojecte,$usuaris){
		$sql="SELECT * from  usuarisprojecte ";
		//where codiusuari=:codiusuari";
		$orde=$this->bd->prepare($sql);
		$orde->bindvalue(':codiprojecte',$codiprojecte);		
		
		$orde->bindvalue(':codiusuari',$usuaris);
		$res=$orde->execute();
		
	}
		
	
}
?>	
