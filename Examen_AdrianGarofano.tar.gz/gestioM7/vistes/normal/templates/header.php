<html>
    <head>
        <title>MVC</title>
    </head>
    <body>
        <nav>
            <ul>
                <li>
                    <a href="index.php">Home       
                    </a>
                </li>
                <li>
                    <a href="index.php?control=controlusuaris&operacio=mostraprojectes">Projectes      
                    </a>
                </li>
                
                
                <li>
                        <a href="index.php?control=controllogin&operacio=logout">Logout       
                        </a>
                </li>
	 <li>
                    <a href='index.php?control=controlusuaris&operacio=canviarcontrasena'>Canviar Contraseña      
                    </a>
                </li>
                
            </ul>
        </nav>

