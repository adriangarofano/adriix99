<?php

		
	
		echo "<h4>Membres del projecte $codiprojecte </h4>";
			
			echo "<table>";
		echo '<th>Codi</th>';
		echo '<th>Username</th>';
		echo '<th>Nom</th>';
		echo '<th>Cognom</th>';
		foreach($llistatMembres as $registre){
		echo "<tr>";
		echo '<td> <b>'.$registre['codi'].'</b></td>';
		echo '<td> <b>'.$registre['username'].'</b></td>';
		echo '<td>'.$registre['nom'].'</td>';
		echo '<td>'.$registre['cognoms'].'</td>';
		echo '<td>';
		echo "<td> <a href='index.php?control=controlprojectes&operacio=treureusuari&codi=".$codiprojecte."&codiu=".$registre['codi']."'>Treure</a>";
 		echo "</tr>";
		}
			echo "</table>";

		echo "<h3>Usuaris no assignats";
		echo "<form method='POST' action='index.php?control=controlprojectes&operacio=usuarisprojecte&codi=".$codiprojecte."'>";
	

		echo "<table>";
		foreach($llistatNoMembres as $registre){
                 echo "<tr>";
		echo '<td><input type="checkbox" name=usuaris[] value='.$registre['codi'].'></td>';
		echo '<td>'.$registre['username'].'</td>';
		echo '<td>'.$registre['nom'].'</td>';
		echo '<td>'.$registre['cognoms'].'</td>';
		echo "</tr>";
		}
		echo "</table>";
	
		echo '<input type="submit" name="enviar" value="enviar">';
	
?>

