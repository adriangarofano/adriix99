

	
<html>
	
	<h3>Canviar Contraseña</h3>
		
	<form method="POST" action="index.php?control=controlusuaris&operacio=canviarcontrasena">
	Introdueix Password <input type="text" name="noupassword" ><br>
  	
 	Reintrodueix Password <input type="text" name="password"><br>
	
	<input type="submit" value="Canvia">
	
	<form>
	
</html> 	

<?php
	
?>
