<?php
      for ($i=1; $i<=$total_pags; $i++) {
          echo "<a href='index.php?control=controlusuaris&pagina=".$i."' >".$i."</a>";
      }
?>

